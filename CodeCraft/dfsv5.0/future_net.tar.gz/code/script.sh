#!/bin/bash
var1="test-case3"
var2="case10-3"
var3="myans"

../batch.sh
rm ../$var1/$var2/case0/$var3
../bin/future_net ../$var1/$var2/case0/topo.csv ../$var1/$var2/case0/demand.csv ../result.csv >> ../$var1/$var2/case0/$var3
rm ../$var1/$var2/case1/$var3
../bin/future_net ../$var1/$var2/case1/topo.csv ../$var1/$var2/case1/demand.csv ../result.csv >> ../$var1/$var2/case1/$var3
rm ../$var1/$var2/case2/$var3
../bin/future_net ../$var1/$var2/case2/topo.csv ../$var1/$var2/case2/demand.csv ../result.csv >> ../$var1/$var2/case2/$var3
rm ../$var1/$var2/case3/$var3
../bin/future_net ../$var1/$var2/case3/topo.csv ../$var1/$var2/case3/demand.csv ../result.csv >> ../$var1/$var2/case3/$var3
rm ../$var1/$var2/case4/$var3
../bin/future_net ../$var1/$var2/case4/topo.csv ../$var1/$var2/case4/demand.csv ../result.csv >> ../$var1/$var2/case4/$var3
rm ../$var1/$var2/case5/$var3
../bin/future_net ../$var1/$var2/case5/topo.csv ../$var1/$var2/case5/demand.csv ../result.csv >> ../$var1/$var2/case5/$var3
rm ../$var1/$var2/case6/$var3
../bin/future_net ../$var1/$var2/case6/topo.csv ../$var1/$var2/case6/demand.csv ../result.csv >> ../$var1/$var2/case6/$var3
rm ../$var1/$var2/case7/$var3
../bin/future_net ../$var1/$var2/case7/topo.csv ../$var1/$var2/case7/demand.csv ../result.csv >> ../$var1/$var2/case7/$var3
rm ../$var1/$var2/case8/$var3
../bin/future_net ../$var1/$var2/case8/topo.csv ../$var1/$var2/case8/demand.csv ../result.csv >> ../$var1/$var2/case8/$var3
rm ../$var1/$var2/case9/$var3
../bin/future_net ../$var1/$var2/case9/topo.csv ../$var1/$var2/case9/demand.csv ../result.csv >> ../$var1/$var2/case9/$var3

:<<!
var4="test-case"
#var5="case9"
rm ../$var4/$var5/$var3
../bin/future_net ../$var4/case8/topo.csv ../$var4/case8/demand.csv ../result.csv
../bin/future_net ../$var4/case0/topo.csv ../$var4/case0/demand.csv ../result.csv
../bin/future_net ../$var4/case1/topo.csv ../$var4/case1/demand.csv ../result.csv
../bin/future_net ../$var4/case9/topo.csv ../$var4/case9/demand.csv ../result.csv
../bin/future_net ../$var4/case3/topo.csv ../$var4/case3/demand.csv ../result.csv
../bin/future_net ../$var4/case4/topo.csv ../$var4/case4/demand.csv ../result.csv
../bin/future_net ../$var4/case5/topo.csv ../$var4/case5/demand.csv ../result.csv
../bin/future_net ../$var4/case7/topo.csv ../$var4/case7/demand.csv ../result.csv
!


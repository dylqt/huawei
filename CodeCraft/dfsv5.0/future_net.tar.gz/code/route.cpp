#include "route.h"
#include "lib_record.h"
#include <stdio.h>

using namespace std;

Path &Path::operator=(const Path &rhs)
{
	cost = rhs.cost;
	start = rhs.start;
	target = rhs.target;
	edges = rhs.edges;
	specialNodes = rhs.specialNodes;
	freeNodes = rhs.freeNodes;

	return *this;
}

Path Path::operator+(const Path &rhs)
{
	Path sum = *this;
	sum.cost = this->cost + rhs.cost;

	if(sum.target == rhs.start) {
		sum.target = rhs.target;
		vector<int> vec(rhs.edges);
		for(unsigned int i = 0; i < sum.edges.size(); i++)
			vec.push_back(sum.edges[i]);
		sum.edges = vec;
	}
	else if(rhs.target == sum.start) {
		sum.start = rhs.start;
		for(unsigned int i = 0; i < rhs.edges.size(); i++)
			sum.edges.push_back(rhs.edges[i]);
	}
		
	for(unsigned int i = 0; i < rhs.specialNodes.size(); i++)
		if(find(sum.specialNodes.begin(), sum.specialNodes.end(), rhs.specialNodes[i]) == sum.specialNodes.end())
			sum.specialNodes.push_back(rhs.specialNodes[i]);

	for(unsigned int i = 0; i < rhs.freeNodes.size(); i++)
		if(find(sum.freeNodes.begin(), sum.freeNodes.end(), rhs.freeNodes[i]) == sum.freeNodes.end())
			sum.freeNodes.push_back(rhs.freeNodes[i]);

	return sum;
}

//打印路径函数
void Path::printPath(class Dijkstra &work)
{
#ifdef PRINT_PAHT
	cout << "Path:" << start << "->" << target << "cost:" << cost << ",edges(";
	for(int i = (int)edges.size() - 1; i >= 0; i--) {
		if(i != 0) cout << edges[i] << '|';
		else cout << edges[i] << ')';
	}
	cout << "\nspNodes(";
	sort(specialNodes.begin(), specialNodes.end());
	for(int i = 0; i < (int)specialNodes.size(); i++){
		if(i != (int)specialNodes.size() - 1) cout << specialNodes[i] << ",";
		else cout << specialNodes[i] << ")";
	}
	cout << "NodesNum:" << specialNodes.size() << endl;

	set<int> nodes;
	cout << "Nodes:" << start << "->";
	for(int i = (int)edges.size() - 1; i >= 0; i--) {
		if(nodes.count(work.edges[edges[i]].to) == 0) nodes.insert(work.edges[edges[i]].to);
		else cout << "(cycle)";	//节点重复出现了
		if(i != 0) cout << work.edges[edges[i]].to << "->";
		else cout << work.edges[edges[i]].to << endl;
	}
	cout << endl;
#endif
}

//处理环
void Path::handleCycle(const Path &rhs, Dijkstra &work)
{
#ifdef HANDLE_CYCLE

	/*bool hasCycle = false;
	for(int i = 0; i < (int)this->freeNodes.size(); i++) { //判断自由节点是否重复
		if(find(rhs.freeNodes.begin(), rhs.freeNodes.end(), this->freeNodes[i]) != rhs.freeNodes.end()) {
			hasCycle = true;
			break;
		}
	}
	if(hasCycle == false) { //判断特殊节点是否重复
		if(this->target == rhs.start) {
			for(int i = 0; i < (int)this->specialNodes.size(); i++) {
				 if(this->specialNodes[i] != this->target &&\
				find(rhs.specialNodes.begin(), rhs.specialNodes.end(), this->specialNodes[i]) !=\
				 rhs.specialNodes.end()) {
					hasCycle = true;
					break;
				}
			}
		}
		else if(this->start == rhs.target) {
			for(int i = 0; i < (int)this->specialNodes.size(); i++) {
				 if(this->specialNodes[i] != this->start &&\
				find(rhs.specialNodes.begin(), rhs.specialNodes.end(), this->specialNodes[i]) !=\
				 rhs.specialNodes.end()) {
					hasCycle = true;
					break;
				}
			}
		}
	}
	if(hasCycle == false) return;*/

	vector<int> repeatNodes;
	for(int i = 0; i < (int)rhs.freeNodes.size(); i++)	//freeNodes不包括起点和终点
		repeatNodes.push_back(rhs.freeNodes[i]);

	for(int i = 0; i < (int)rhs.specialNodes.size(); i++)	//
		if(this->target == rhs.start && rhs.specialNodes[i] != rhs.start)
			repeatNodes.push_back(rhs.specialNodes[i]);
		else if(this->start == rhs.target && rhs.specialNodes[i] != rhs.target)
			repeatNodes.push_back(rhs.specialNodes[i]);

	if(this->target != work.target) repeatNodes.push_back(work.target);
	if(this->start != work.start) repeatNodes.push_back(work.start);
	//cout << "repeatNodes:" << endl;
	//for(int i = 0; i < (int)repeatNodes.size(); i++) cout << repeatNodes[i] << ' ';
	//cout << endl;

	if(repeatNodes.size() == 0) return ;
	else {
		work.dijkstra(this->start, repeatNodes);
		work.BuildPath(this->start, this->target, *this);
	}
#endif
}

//对当前路径插入一个不包含的特殊节点
bool Path::insertSpNodes(Dijkstra &work)
{
	for(int i = 0; i < (int)work.includingSet.size(); i++) { //遍历所有特殊节点，找到哪个特殊节点还没有插入
		if(find(this->specialNodes.begin(), this->specialNodes.end(), work.includingSet[i]) == this->specialNodes.end()) {
			for(int j = (int)this->edges.size() - 1; j >= 0; j--) { //遍历边，看能在哪里插入
				int start, target; //在这两个节点之间插入特殊节点
				if(j == (int)this->edges.size() - 1)
					start = work.edges[this->edges[j]].from, target = work.edges[this->edges[j]].to; 
				else {
					start = target;
					target = work.edges[this->edges[j]].to;
				}

				vector<int> rmNodes; //不能经过的节点
				Path tmp1, tmp2; //新添加的两条路径

				rmNodes.clear();	
				rmNodes.push_back(work.start);
				rmNodes.push_back(work.target);
				for(int isp = 0; isp < (int)specialNodes.size(); isp++)
					if(this->specialNodes[isp] != start) rmNodes.push_back(this->specialNodes[isp]);
				for(int ifr = 0; ifr < (int)freeNodes.size(); ifr++)
					if(this->freeNodes[ifr] != start) rmNodes.push_back(this->freeNodes[ifr]);

				work.dijkstra(start, rmNodes);
				work.BuildPath(start, work.includingSet[i], tmp1); //构造第一条路径

				if(tmp1.cost < 0) continue;

				rmNodes.clear();
				rmNodes.push_back(work.start);
				if(target != work.target) rmNodes.push_back(work.target);
				for(int isp = 0; isp < (int)specialNodes.size(); isp++)
					if(this->specialNodes[isp] != target) rmNodes.push_back(this->specialNodes[isp]);
				for(int ifr = 0; ifr < (int)freeNodes.size(); ifr++)
					if(this->freeNodes[ifr] != target) rmNodes.push_back(this->freeNodes[ifr]);
				for(int itm = 0; itm < (int)tmp1.freeNodes.size(); itm++) rmNodes.push_back(tmp1.freeNodes[itm]);

				work.dijkstra(work.includingSet[i], rmNodes);
				work.BuildPath(work.includingSet[i], target, tmp2); //构造第二条路径

				if(tmp1.cost > 0 && tmp2.cost > 0) { //构造路径成功
					this->cost += tmp1.cost + tmp2.cost;
					this->specialNodes.push_back(work.includingSet[i]);
					for(int i = 0; i < (int)tmp1.freeNodes.size(); i++)
						this->freeNodes.push_back(tmp1.freeNodes[i]);
					for(int i = 0; i < (int)tmp2.freeNodes.size(); i++)
						this->freeNodes.push_back(tmp2.freeNodes[i]);	
			
					vector<int> tmpedges; //新路径的边
					for(int i = 0; i < (int)this->edges.size(); i++) {
						if(i != j) tmpedges.push_back(this->edges[i]);
						else {
							for(int k = 0; k < (int)tmp2.edges.size(); k++)
								tmpedges.push_back(tmp2.edges[k]);
							for(int k = 0; k < (int)tmp1.edges.size(); k++)
								tmpedges.push_back(tmp1.edges[k]);
						}
					}
					this->edges = tmpedges;

					return true; //节点插入成功
				}
				else continue;
			} //遍历边
		}
		else continue; //特殊节点已经包含
	}
	return false;
}

//当前路径是否是答案
bool Path::pathIsAns(Dijkstra &work)
{
	set<int> allNodes;
	vector<int> spNodes;

	for(int i = (int)this->edges.size() - 1; i >= 0; i--) {
		if(i == (int)this->edges.size() - 1) {
			allNodes.insert(work.edges[this->edges[i]].from);
			allNodes.insert(work.edges[this->edges[i]].to);
			if(find(work.includingSet.begin(), work.includingSet.end(), work.edges[this->edges[i]].to)\
		          != work.includingSet.end()) {
				spNodes.push_back(work.edges[this->edges[i]].to);
				//cout << work.edges[this->edges[i]].to << endl;
			}
		}
		else {
			if(work.edges[this->edges[i]].from != work.edges[this->edges[i + 1]].to) { //边不能构成路径
				cout << "edges error!" << endl;
				return false;
			}
			if(allNodes.count(work.edges[this->edges[i]].to) != 0) { //有重复的节点（同时判断自由节点和特殊节点）
				cout << "repet!" << work.edges[this->edges[i]].to << endl;
				return false;
			}
			else { //节点未重复
				allNodes.insert(work.edges[this->edges[i]].to);			
				if(find(work.includingSet.begin(), work.includingSet.end(), work.edges[this->edges[i]].to) \
				   != work.includingSet.end()) { //此节点是特殊节点
					spNodes.push_back(work.edges[this->edges[i]].to);
					//cout << work.edges[this->edges[i]].to << endl;
				}
			}
		}
	}

	if(spNodes.size() < work.includingSet.size()) { //特殊节点个数不够
		cout << "not all spNodes!" << spNodes.size() << endl;
		return false;
	}
	else return true;
}

void Dijkstra::init(char *topo[5000], int edge_num, char *demand) {	//用节点数目初始化
	m = edge_num;
	n = 0;

	for (int i = 0; i < maxn; i++) G[i].clear();
	edges.clear();

	int index, from, to, dist;
	char tmp;
	for(int i = 0; i < edge_num; i++){
		stringstream ss;
		ss << topo[i];
	    	ss >> index >> tmp >> from >> tmp >> to >> tmp >> dist;
		this->AddEdge(index, from, to, dist);	
	}

	stringstream ss;
	ss << demand;
	ss >> this->start >> tmp >> this->target >> tmp;
	do{
		ss >> from;
		includingSet.push_back(from);
	}while(ss >> tmp);
}

void Dijkstra::AddEdge(int index, int from, int to, int dist) {	//添加一条边
	while(1) {
		if((int)edges.size() >= index) {
			edges.push_back(Edge(index, from, to, dist));	//此处假设边的读入顺序和index相同。否则需要事先设计edges的大小。
			break;
		}
		else edges.push_back(Edge(-1, -1, -1, -1));
	}
	//m = edges.size();
	int tmp = max(from, to);
	this->n = max(this->n, tmp + 1);
	G[from].push_back(index);
}

void Dijkstra::dijkstra(int s, const vector<int> rmNodes) {	//计算起点到各个点的最短路径
	
	for (int i = 0; i < n; i++) d[i] = INT_MAX;	//初始化d数组
	d[s] = 0;

	memset(done, 0, sizeof(done));	//初始化done数组
	for(int i = 0; i < (int)rmNodes.size(); i++)	//把移除的节点标记为已经完成
		done[rmNodes[i]] = true;
		
	memset(p, -1, sizeof(p));	//-1表示没有这条边
	priority_queue<HeapNode> Q;
	Q.push(HeapNode(0, s));	//把起点加入队列

	while (!Q.empty()) {
		HeapNode x = Q.top(); Q.pop();
		int u = x.u;
		if (done[u]) continue;
		done[u] = true;
		for (unsigned int i = 0; i < G[u].size(); i++) {	//	遍历节点u的所有边
			Edge& e = edges[G[u][i]];
			if (d[e.to] > d[u] + e.dist) {
				d[e.to] = d[u] + e.dist;
				p[e.to] = G[u][i];
				Q.push(HeapNode(d[e.to], e.to));
			}
		}
	}
}

void Dijkstra::BuildPath(int vi, int vl, Path& path)
{
	path.cost = this->d[vl];
	path.start = vi;
	path.target = vl;
	path.edges.clear();
	path.specialNodes.clear();
	path.freeNodes.clear();

	for(int i = vl; ; ){	//从终点开始
		if(find(this->includingSet.begin(), this->includingSet.end(), i) != this->includingSet.end())
			path.specialNodes.push_back(i);
		else if(i != vi && i != vl) path.freeNodes.push_back(i);

		if(this->p[i] == -1) {
			path.cost = -1;
			break;	//不存在这条路径
		}
		path.edges.push_back(this->p[i]);	//找到一条边
		if((i = this->edges[this->p[i]].from) != vi) continue;
		else{
			if(find(this->includingSet.begin(), this->includingSet.end(), i) != this->includingSet.end())
				path.specialNodes.push_back(i);
			break;
		}
	}
}

int Dijkstra::nodeNums(void)
{
	return n;
}

void Dijkstra::print_p(void)
{
	for(int i = 0; i < this->n; i++)
		cout << p[i] << ' ';
	cout << endl;
}

void Dijkstra::print_information(void)
{
	cout << "start:" << start << " target:" << target << endl;
	for(unsigned int i = 0; i < includingSet.size(); i++)
		cout << includingSet[i] << '|';
	cout << endl;

	cout << "最短路径中，每个节点的上一条边的编号：" << endl; 
	for(int i = 0; i < n; i++)
		cout << this->p[i] << '|';
	cout << endl;

	cout << "节点总数n:" << n << ",边总数m:" << m << endl;
}

void BFS::init(char *topo[5000], int edge_num, char *demand)
{
	memset(G, -1, sizeof(G));
	int index, from, to, dist;
	char tmp;
	allNodesNum = -1;

	for(int i = 0; i < edge_num; i++){
		stringstream ss;
		ss << topo[i];
	    	ss >> index >> tmp >> from >> tmp >> to >> tmp >> dist;
		//cout << index << from << to << dist << endl;
		//cout << "G0:" << G[0][from][to];
		if(G[0][from][to] == -1 || dist < G[0][from][to]) {
			G[0][from][to] = dist;
			G[1][from][to] = index;
			//cout << "G0:" << G[0][from][to] << "G1" << G[1][from][to] << endl;
		}

		int tmp = max(from, to);
		allNodesNum = max(allNodesNum, tmp + 1);
	}

	stringstream ss;
	ss << demand;
	ss >> start >> tmp >> target >> tmp;
	do{
		ss >> from;
		includingSet.push_back(from);
	}while(ss >> tmp);

	bestAns.clear();
	bestCost = INT_MAX;
	for(int i = 0; i < allNodesNum; i++) done.push_back(false);

#ifdef DEBUG
	cout << "allNodesNum:" << allNodesNum << endl;
	for(int i = 0; i < allNodesNum; i++) {
		for(int j = 0; j < allNodesNum; j++) {
			if(G[0][i][j] != INT_MAX) cout << G[1][i][j] << "(" << G[0][i][j] << ") ";
		}
		cout << endl;
	}
	cout << "start:" << start << " target:" << target << endl;
	cout << "bestCost:" << bestCost << endl;
	cout << "spNodes:";
	for(int i = 0; i < (int)includingSet.size(); i++) cout << includingSet[i] << ' ';
	cout << endl;
	cout << "done:";
	for(int i = 0; i < (int)done.size(); i++) cout << done[i] << ' ';
	cout << endl;
#endif
}

void BFS::bfs(void)
{
	int spNum = 0; //当前路径特殊节点个数

	stack<Edge> path; //当前路径
	int cost = 0; //当前路径权重

	stack<vector<int> > stk; //节点遍历
	int u = start;

	vector<int> tmp;
	tmp.push_back(u);
	tmp.push_back(-1);
	stk.push(tmp);

	done[u] = true;

	while(stk.size() != 0) {
		//cout << "stack top:" << stk.top()[0] << " stack top bound:" << stk.top()[1] << endl;
		int hasPath = false;
		for(int i = 0; i < allNodesNum; i++) {
			/*cout << "done:";
			for(int id = 0; id < (int)done.size(); id++) cout << done[id] << ' ';
			cout << "\nu:" << u << " i:" << i << " edge:" << G[1][u][i] << " cost:" << G[0][u][i] << endl;*/
			if(i <= stk.top()[1] || u == i || done[i] == true || G[0][u][i] == -1) 
			{
				//cout << "continue;" << endl;
				continue;

			}
			else {
				//cout << "inn" << endl;
				hasPath = true;
				path.push(Edge(G[1][u][i], u, i, G[0][u][i]));
				cost += G[0][u][i];
				if(find(includingSet.begin(), includingSet.end(), i) != includingSet.end()) spNum++;
				done[i] = true;
			
				vector<int> tmp;
				tmp.push_back(i);
				tmp.push_back(-1);
				stk.top()[1] = i;
				stk.push(tmp);

				/*cout << "current cost:" << cost << endl;
				cout << "spNum:" << spNum << endl;
				cout << "done:";
				for(int id = 0; id < (int)done.size(); id++) cout << done[id] << ' ';
				cout << endl;
				if(stk.size() != 0) cout << "stack top:" << stk.top()[0] << " stack top bound:" << stk.top()[1] << endl;
				cout << "stk.size:" << stk.size() << endl;
				cout << "Path.size:" << path.size() << endl;
				if(path.size() != 0) cout << "path top:" << path.top().num << ' ' << path.top().from << ' ' << path.top().to << ' ' << endl;*/

				if(i == target) {
					//cout << "bestcost:" << bestCost << endl;
					if(spNum == (int)includingSet.size() && cost < bestCost) { //找到一条路径
						//cout << "find cost:" << cost << endl;
						stack<Edge> tmp = path;
						bestAns.clear();
						while(!tmp.empty()) {
							bestAns.push_back(tmp.top().num);
							tmp.pop();
						}
						bestCost = cost;
					}	
					else if(spNum == (int)includingSet.size() && cost > bestCost) {
						//cout << "find cost:" << cost << endl;
					}
					if(find(includingSet.begin(), includingSet.end(), path.top().to) != includingSet.end()) spNum--;
					path.pop();
					
					cost -= G[0][u][i];
					done[i] = false;	
					hasPath = false;
					stk.pop();
					//cout << "\ncurrent cost:" << cost << endl;	
				}
				else {
					u = i;
					break;
				}
			} // for
		}
		if(hasPath == false) {
			//cout << "\nno path:" << endl;
			if(!stk.empty()) {
				stk.pop();
				if(!stk.empty()) u = stk.top()[0];
			}
			
			if(!path.empty()) {
				cost -= path.top().dist;
				done[path.top().to] = false;
				if(find(includingSet.begin(), includingSet.end(), path.top().to) != includingSet.end()) spNum--;
				path.pop();
			}
		/*if(stk.size() != 0) cout << "stack top:" << stk.top()[0] << " stack top bound:" << stk.top()[1] << endl;
		cout << "stk.size:" << stk.size() << endl;
		cout << "Path.size:" << path.size() << endl;
		if(path.size() != 0) cout << "path top:" << path.top().num << ' ' << path.top().from << ' ' << path.top().to << ' ' << endl;*/
		}
	} //while

		//cout << "bfs success!" << endl;
}

void BFS::outPut(void)
{
	/*cout << "best cost:" << bestCost << endl;
	for(int i = (int)bestAns.size() - 1; i >= 0; i--)
		cout << bestAns[i] << ' ';
	cout << endl;*/

	for(int i = bestAns.size() - 1; i >= 0; i--)
		record_result(bestAns[i]);
}

void BFS::print_information(void)
{
}

void SK66::sk66(char *topo[5000], int edge_num, char *demand)
{
	Dijkstra work;
	work.init(topo, edge_num, demand);


	//这个D很大，需要缩小，600点肯定段错误
	const int allNodesNum = work.nodeNums();
	Path D[allNodesNum][allNodesNum];	//i:表示起点编号 j:表示终点编号;两点之间的最短路径矩阵

	const int spNodesNum = work.includingSet.size();
	Path f[spNodesNum - 1][spNodesNum];	//路径经过哪些边的矩阵。
	Path f0;
	//初始化矩阵
	memset(D, 0, sizeof(D));
	memset(f, 0, sizeof(f));

	//Dijkstra构造两两之间的最短路径，若路径不存在其权重为-1
	for(int i = 0; i < allNodesNum; i++) {
		if(find(work.includingSet.begin(), work.includingSet.end(), i) != work.includingSet.end() || i == work.start){	
			vector<int> rmNodes;
			rmNodes.clear();	
			work.dijkstra(i, rmNodes);
			for(int j = 0; j < allNodesNum; j++){
				if(i == j) continue;
				if(find(work.includingSet.begin(), work.includingSet.end(), j) != work.includingSet.end() || j == work.target){
					work.BuildPath(i, j, D[i][j]);
					D[i][j].printPath(work);
				}
			}
		//	work.print_information();
		}
	}

	//SK66迭代
	int vi, vl, addvl, addj;	//vi:起点 vl:终点 
	for(int i = 0; i < spNodesNum; i++) {	//i:只表示需要循环的次数
		cout << "i=" << i << endl;
		if(i == 0) {
			for(int j = 0; j < (int)work.includingSet.size(); j++) {	//j:遍历起点
				vi = work.includingSet[j];
				int min = INT_MAX;
				for(int k = 0; k < (int)work.includingSet.size(); k++) {	//k:遍历终点
					if(j == k) continue;
					vl = work.includingSet[k];
					if(D[vi][vl].cost > 0 && D[vi][vl].cost + D[vl][work.target].cost < min) {
						min = D[vi][vl].cost + D[vl][work.target].cost;
						addvl = vl; //要添加的中间节点是哪一个。
					}
				}	
				f[i][j] = D[vi][addvl] + D[addvl][work.target];
				if((int)f[i][j].specialNodes.size() - 1 < i + 1) f[i][j].cost = -1; //the path is not admissible
			}
		}
		else if(i == spNodesNum - 1) {
				int min = INT_MAX;
				addvl = addj = -1;
				for(int k = 0; k < (int)work.includingSet.size(); k++) {	//k:遍历终点
					vl = work.includingSet[k];
					if(D[work.start][vl].cost > 0 && f[i - 1][k].cost > 0 && D[work.start][vl].cost + f[i - 1][k].cost < min) {
						min = D[work.start][vl].cost + f[i - 1][k].cost;
						addvl = vl; //要添加的中间节点是哪一个。
						addj = k;
					}
				}	
				if(addvl != -1) {
					f0 = D[work.start][addvl] + f[i - 1][addj];
					if((int)f0.specialNodes.size() < i + 1) f0.cost = -1; //the path is not admissible				
				}
				else cout << "NA" << endl;
				
		}
		else {
			for(int j = 0; j < (int)work.includingSet.size(); j++) {	//j:遍历起点
				vi = work.includingSet[j];
				int min = INT_MAX;
				addvl = addj = -1;
				for(int k = 0; k < (int)work.includingSet.size(); k++) {	//k:遍历终点
					if(j == k) continue;
					vl = work.includingSet[k];
					if(D[vi][vl].cost > 0 && f[i - 1][k].cost > 0 && D[vi][vl].cost + f[i - 1][k].cost < min &&\
		find(f[i - 1][k].specialNodes.begin(), f[i - 1][k].specialNodes.end(), vi) != f[i - 1][k].specialNodes.end()) {
						min = D[vi][vl].cost + f[i - 1][k].cost;
						addvl = vl; //要添加的中间节点是哪一个。
						addj = k;
					}
				}	
				if(addvl != -1) f[i][j] = D[vi][addvl] + f[i - 1][addj];
				else f[i][j] = f[i - 1][j];
				if((int)f[i][j].specialNodes.size() - 1 < i + 1) f[i][j].cost = -1; //the path is not admissible
			}
		}	
		//打印迭代过程
		for(int l = 0; i != spNodesNum - 1 && l < spNodesNum; l++)
			f[i][l].printPath(work);
		if(i == spNodesNum - 1) f0.printPath(work);
	}
}


//你要完成的功能总入口
void search_route(char *topo[5000], int edge_num, char *demand)
{
#ifdef PRINT_INPUT
	cout << "接口输入实参：" << endl;
	cout << "edge_num:" << edge_num << endl;
	cout << "topo:" << endl;
	for (int i = 0; i < edge_num; i++)
		cout << topo[i];
	cout << endl;
	cout << "demand:" << endl;	
	cout << demand << endl;
#endif

	//SK66 work;
	//work.sk66(topo, edge_num, demand);	case1：在类内调用使用19ms，不用类使用4ms

	if(1) {
		BFS bfswork;
		bfswork.init(topo, edge_num, demand);
		bfswork.bfs();
		bfswork.outPut();
		return;
	}
	

	Dijkstra work;
	work.init(topo, edge_num, demand);
	
	//const int allNodesNum = work.nodeNums();
	const int spNodesNum = work.includingSet.size();

	//这个D只能包好必须经过的节点和起点and终点。这里面的点的下标和includingSet中的下标必须一致，起点放最后一行，终点放最后一列。
	Path D[spNodesNum + 1][spNodesNum + 1];	//i:表示起点编号 j:表示终点编号;两点之间的最短路径矩阵,
	Path f[spNodesNum][spNodesNum][spNodesNum];	//路径经过哪些边的矩阵。
	Path f0[spNodesNum];
	//初始化矩阵

	bool hasPath = false; //一次迭代后是否还有有效路径
	bool notChangeD = true;
	//int outCost = INT_MAX;
	Path outPath;
	outPath.cost = INT_MAX;

beginSK:
	memset(D, 0, sizeof(D));
	memset(f, 0, sizeof(f));
	memset(f0, 0, sizeof(f0));

	//Dijkstra构造两两之间的最短路径，若路径不存在其权重为-1
#ifdef DEBUG
	cout << "Dijkstra:" << endl;
#endif
	vector<int> rmNodes;
	for(int i = 0; i < spNodesNum; i++) {	//在special nodes中遍历起点
		rmNodes.clear();
		rmNodes.push_back(work.start);
		rmNodes.push_back(work.target);	
		work.dijkstra(work.includingSet[i], rmNodes);	//移除起点和终点进行计算
		for(int j = 0; j < spNodesNum; j++){
			if(i == j) continue;
			work.BuildPath(work.includingSet[i], work.includingSet[j], D[i][j]);
			D[i][j].printPath(work);
		}

		rmNodes.clear();
		rmNodes.push_back(work.start);	//只移除起点进行计算
		work.dijkstra(work.includingSet[i], rmNodes);	

		work.BuildPath(work.includingSet[i], work.target, D[i][spNodesNum]);
		D[i][spNodesNum].printPath(work);
	}
	rmNodes.clear();
	rmNodes.push_back(work.target);	//只移除终点进行计算
	work.dijkstra(work.start, rmNodes);	
	for(int j = 0; j < spNodesNum; j++){
		work.BuildPath(work.start, work.includingSet[j], D[spNodesNum][j]);
		D[spNodesNum][j].printPath(work);
	}

	//SK迭代
	//int vi, vl;	//vi:起点 vl:终点 
	for(int i = 0; i < spNodesNum; i++) {	//i:只表示需要循环的次数
#ifdef DEBUG
		cout << "SK迭代i=" << i << endl;
#endif
		if(i == 0) {
			for(int j = 0; j < (int)work.includingSet.size(); j++) {	//j:遍历起点--vi
				//vi = work.includingSet[j];
				for(int k = 0; k < (int)work.includingSet.size(); k++) {	//k:遍历终点--vl
					if(j == k) continue;
					//vl = work.includingSet[k];
					if(D[j][k].cost > 0 && D[k][spNodesNum].cost > 0) {
						Path tmp = D[j][k];
						D[j][k].handleCycle(D[k][spNodesNum], work);
						if(D[j][k].cost != -1) {
							f[i][j][k] = D[j][k] + D[k][spNodesNum];
						}
						else {
							D[j][k] = tmp;
							D[k][spNodesNum].handleCycle(D[j][k], work);					
							if(D[k][spNodesNum].cost != -1) {
								f[i][j][k] = D[j][k] + D[k][spNodesNum];
							}
							else f[i][j][k].cost = -1;		
						}
						if(notChangeD) D[j][k] = tmp;
						//else f[i][j][k].cost = -1;
					}
					else f[i][j][k].cost = -1;	//这次迭代不存在这条路径

					//SK66中每步都要判断，SK中应该也要吧,(2 - 1 < 0 + 1 一定不满足)
					if(f[i][j][k].cost > 0 && \
					(int)f[i][j][k].specialNodes.size() - 1 < i + 1) f[i][j][k].cost = -1; //the path is not admissible
				}	
			}
		}
		else {
			for(int j = 0; j < (int)work.includingSet.size(); j++) {	//j:遍历起点
				//vi = work.includingSet[j];
				for(int k = 0; k < (int)work.includingSet.size(); k++) {	//k:遍历终点
					if(j == k) continue;
					//vl = work.includingSet[k];

					int min = INT_MAX;
					int addk[spNodesNum], addl[spNodesNum];
					memset(addk,  -1, sizeof(addk));
					memset(addl,  -1, sizeof(addl));
					if(D[j][k].cost > 0) {
						for(int l = 0; l < (int)work.includingSet.size(); l++) {
							if(k == l || j == l) continue;	//跳过起点和终点相同，或者出现环。
							if(f[i - 1][k][l].cost > 0 &&\
							D[j][k].cost + f[i - 1][k][l].cost < min) {
								min = D[j][k].cost + f[i - 1][k][l].cost;
								if(addk[0] != -1) {
									addk[1] = addk[0];
									addk[0] = k;
								}
								else addk[0] = k;

								if(addl[0] != -1) {
									addl[1] = addl[0];
									addl[0] = l;
								}
								else addl[0] = l;
							}	
						}
					}
					else {
						f[i][j][k].cost = -1;
						continue;
					}
				
					//若addk = -1,则D[j][k].cost < 0 || f[i - 1][k][l].cost < 0.

					//此处3个条件还要研究论文
					if(addk[0] != -1) {	//找到一条路径（若addk==-1则之前也不可能有这条路径）
						Path tmp = D[j][k];
						D[j][k].handleCycle(f[i - 1][addk[0]][addl[0]], work);
						if(D[j][k].cost != -1) {
							f[i][j][k] = D[j][k] + f[i - 1][addk[0]][addl[0]];
						}
						else f[i][j][k].cost = -1;
						if(notChangeD) D[j][k] = tmp;
						//from SK66
						//if((int)f[i][j][k].specialNodes.size() - 1 < i + 1) f[i][j][k].cost = -1; 
						if((int)f[i][j][k].specialNodes.size() < i + 1) {
							f[i][j][k].cost = -1;//the path is not admissible
						} 						
						//SK--(2)--(3)
						//if(f[i][j][k].cost < 0 && (int)f[i - 1][j][k].specialNodes.size() >= spNodesNum - 1)
						if(f[i][j][k].cost < 0 && (int)f[i - 1][j][k].specialNodes.size() >= i + 1) {
							f[i][j][k] = f[i - 1][j][k];
						}
						if((int)f[i][j][k].specialNodes.size() >= i + 1 &&\
					           (int)f[i - 1][j][k].specialNodes.size() == (int)f[i][j][k].specialNodes.size() &&\
						   f[i - 1][j][k].cost < f[i][j][k].cost) {
							f[i][j][k] = f[i - 1][j][k];
						}

						/*if((int)f[i][j][k].specialNodes.size() >= i + 1) {
							for(int vi = 0; vi < spNodesNum; vi++) {
								if((int)f[i - 1][j][vi].specialNodes.size() >= i + 1 && \
find(f[i - 1][j][vi].specialNodes.begin(), f[i - 1][j][vi].specialNodes.end(), work.includingSet[k]) != f[i - 1][j][vi].specialNodes.end() && f[i - 1][j][vi].cost < f[i][j][k].cost) 
								{
									cout << "QT" << endl;
									f[i][j][k] = f[i - 1][j][vi];	
								}
							}
						}*/
						/*if((int)f[i][j][k].specialNodes.size() >= i) {
							for(int vi = 0; vi < spNodesNum; vi++) {
								if((int)f[i - 1][j][vi].specialNodes.size() >= i + 1 && \
find(f[i - 1][j][vi].specialNodes.begin(), f[i - 1][j][vi].specialNodes.end(), work.includingSet[k]) != f[i - 1][j][vi].specialNodes.end() && f[i - 1][j][vi].cost < f[i][j][k].cost) 
								{
									f[i][j][k] = f[i - 1][j][vi];	
								}
							}
						}*/
					}
					else if((int)f[i - 1][j][k].specialNodes.size() >= i + 1) {
						f[i][j][k] = f[i - 1][j][k];				
					}
					else f[i][j][k].cost = -1;	//此条路径终结				
				}	
			}
		} //迭代结束
#ifdef DEBUG
		//打印迭代过程
		for(int j = 0; j < spNodesNum; j++) {		
			for(int k = 0; k < spNodesNum; k++) {
				if(j != k && f[i][j][k].cost > 0) {
					f[i][j][k].printPath(work);
				}
			}
		}
#endif
		//判断是否存在有效路径
		hasPath = false;
		for(int j = 0; j < spNodesNum; j++) {		
			for(int k = 0; k < spNodesNum; k++) {
				if(j != k && f[i][j][k].cost > 0) {
					hasPath = true;
				}
			}
		}

		if(hasPath == true) 
			continue;
			//cout << "has path\n" << endl;
		else {
			//cout << "no path\n" << endl;
#ifdef INSERT
			for(int j = 0; j < spNodesNum; j++) {		
				for(int k = 0; k < spNodesNum; k++) {
					if(j != k && f[i - 1][j][k].cost > 0) {
						if(f[i - 1][j][k].insertSpNodes(work) == true) {
							//cout << "insert success!" << endl;
							f[i][j][k] = f[i - 1][j][k];
							f[i][j][k].printPath(work);
						}
						//else cout << "insert not success!" << endl;
					}
				}
			}
#endif
		}
	}//迭代循环
	
	//vi = work.start;
	for(int i = 0; i < (int)work.includingSet.size(); i++) {	//遍历D中的终点，也就是f中的起点
		//vl = work.includingSet[i];
		int min = INT_MAX;
		int addi[spNodesNum], addj[spNodesNum];
		memset(addi, -1, sizeof(addi));
		memset(addj, -1, sizeof(addj));

		for(int j = 0; j < (int)work.includingSet.size(); j++) {	//遍历f中的终点
			if(i == j) continue;
			if(D[spNodesNum][i].cost > 0 && f[spNodesNum - 1][i][j].cost > 0 && D[spNodesNum][i].cost + f[spNodesNum - 1][i][j].cost < min) {
				min = D[spNodesNum][i].cost + f[spNodesNum - 1][i][j].cost;
				if(addi[0] != -1) {
					addi[1] = addi[0];
					addi[0] = i;
				}
				else addi[0] = i;
				if(addj[0] != -1) {
					addj[1] = addj[0];
					addj[0] = j;
				}
				else addj[0] = j;
			}
		}

		if(addi[0] != -1) {
			D[spNodesNum][i].handleCycle(f[spNodesNum - 1][addi[0]][addj[0]], work);	
			if(D[spNodesNum][i].cost != -1) {
				f0[i] = D[spNodesNum][i] + f[spNodesNum - 1][addi[0]][addj[0]];
			}
			else f0[i].cost = -1;
		}
		else f0[i].cost = -1;
	}

#ifdef DEBUG
	//打印路径信息
	cout << "f0:" << endl;
	hasPath = false;
	for(int i = 0; i < spNodesNum; i++)
		if(f0[i].cost > 0) {
			hasPath = true;
			f0[i].printPath(work);
			if(f0[i].pathIsAns(work) == true) cout << "ans is true!" << endl;
			else cout << "ans is false! has bug!" << endl;
		}

	if(hasPath == true) {
		//这里可以尝试减小权值
		cout << "has ans\n" << endl;
	}
	else {	
		//这里可能可以优化
		cout << "no ans\n" << endl;	
	}
#endif

#ifdef GAME
	int min = INT_MAX;
	int ans = -1;
	for(int i = 0; i < spNodesNum; i++) {
		if(f0[i].cost > 0 && f0[i].cost < min) {
			min = f0[i].cost;
			ans = i;
		}
	}

	if(ans != -1) {
		if(f0[ans].cost < outPath.cost) 
			outPath = f0[ans];

		if(notChangeD == true) {
			notChangeD = false;
			goto beginSK;
		}
		else {
			for(int i = (int)outPath.edges.size() - 1; i >= 0; i--)
				record_result(outPath.edges[i]);
		}
	}
	else if(outPath.cost < INT_MAX) {
		for(int i = (int)outPath.edges.size() - 1; i >= 0; i--)
			record_result(outPath.edges[i]);
	}
	else {
		if(notChangeD == true) {
			notChangeD = false;
			goto beginSK;
		}
	}
	//cout << outPath.cost << endl;
#endif
}

# HuaWei2016
Huawei software 2016 championship code
